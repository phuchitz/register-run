import React, { useState, useEffect } from 'react'
import { v4 as uuidv4 } from 'uuid';
import FirstStep from './Step1';
import SecondStep from './Step2';
import Step1 from './Step1';
import Step2 from './Step2';
import Step3 from './Step3';
import Step4 from './Step4';
import { Button } from 'reactstrap';
import StepSubmit from './StepSubmit';

const Process = () => {
    const [currentStep, setCurrentStep] = useState(1);
    const [formData, setFormData] = useState(() => {
        const storedFormData = localStorage.getItem('formData');
        return storedFormData ? JSON.parse(storedFormData) : {
            nameTitleThai: '',
            nameTitleEng: '',
            surnameThai: '',
            surnameEng: '',
            lastNameThai: '',
            lastNameEng: '',
            birthDate: '',
            email: '',
            idCardNumber: '',
            image: '',
            nameBanner: '',
            everCompleted: '',
            expectedTimeH: 0,
            expectedTimeM: 0,
            emfullName1: '',
            emRelationship1: '',
            emTel1: '',
            emfullName2: '',
            emRelationship2: '',
            emTel2: '',
            medBloodType: '',
            medDrugAllery: '',
            medCongenitalDisease: '',
            medPlanChildren: '',
            medRegularBasis: '',
            medInjuryIllness: '',
            medExRegularly: '',
            medChest: '',
        };
    });

    useEffect(() => {
        localStorage.setItem('formData', JSON.stringify(formData));
      }, [formData]);

    const nextStep = () => setCurrentStep((prev) => prev + 1);

    const prevStep = () => setCurrentStep((prev) => prev - 1);

    const handleSubmit = () => {
      // You can perform any final submission logic here
      alert('Form submitted successfully!');


    };

    const renderStep = () => {
        switch (currentStep) {
          case 1:
            return <Step1 formData={formData} setFormData={setFormData} nextStep={nextStep} />;
          case 2:
            return <Step2 formData={formData} setFormData={setFormData} nextStep={nextStep} prevStep={prevStep} />;
          case 3:
            return <Step3 formData={formData} setFormData={setFormData} nextStep={nextStep} prevStep={prevStep} />;
          case 4:
            return <Step4 formData={formData} setFormData={setFormData} nextStep={nextStep} prevStep={prevStep} />;
          case 5:
            return <StepSubmit formData={formData} setFormData={setFormData} prevStep={prevStep} handleSubmit={handleSubmit} />;
          default:
            return null;
        }
      };
  return (
    <div>
        {renderStep()}
    </div>
  )
}

export default Process