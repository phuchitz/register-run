import React from 'react'
import Process from './Process'

function Header() {
  return (
    <div>
        <h1>ระบบการลงทะเบียนนักวิ่งที่จะเข้ามาสมัครวิ่งในงาน</h1>
    </div>
  )
}

export default Header