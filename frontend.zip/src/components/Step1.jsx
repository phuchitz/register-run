/* eslint-disable no-undef */
import React, { useState , useEffect} from "react";
import {
  Form,
  Button,
  Label,
  FormGroup,
  Input,
  Container,
  FormFeedback,
  FormText,
} from "reactstrap";
//import * as  from 'react-bootstrap';

const Step1 = ({ formData, setFormData, nextStep }) => {

  const [selectedFile, setSelectedFile] = useState(null);

  const [file, setFile] = useState(null);
  const [fileDataURL, setFileDataURL] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleFileChange = (e) => {
    // const file = e.target.files[0];
    // setSelectedFile(file);
    //setFile(URL.createObjectURL(file));
    const file = e.target.files[0];
    if (!file.type.match(imageMimeType)) {
      alert("Image mime type is not valid");
      return;
    }
    setFile(file);
  };

  useEffect(() => {
    let fileReader, isCancel = false;
    if (file) {
      fileReader = new FileReader();
      fileReader.onload = (e) => {
        const { result } = e.target;
        if (result && !isCancel) {
          setFileDataURL(result)
        }
      }
      fileReader.readAsDataURL(file);
    }
    return () => {
      isCancel = true;
      if (fileReader && fileReader.readyState === 1) {
        fileReader.abort();
      }
    }

  }, [file]);


  const handleNext = () => {
    setFormData({ ...formData, file: fileDataURL }); // Include the selected file in formData
    nextStep();
  };

  return (
    <div>
      <Container>
        <h1>1 ข้อมูลส่วนตัว</h1>
        <Form className="input-form">
          <FormGroup>
            <div className="col-md-3">
              <Label for="exampleSelect">คำนำหน้าชื่อ</Label>
              <Input
                id="nameTitleThai"
                name="nameTitleThai"
                type="select"
                value={formData.nameTitleThai || ''}
                onChange={handleChange}
                required
              >
                <option value="">เลือกคำนำหน้า</option>
                <option value="นาย">นาย</option>
                <option value="นาง">นาง</option>
                <option value="น.ส.">นางสาว</option>
                <option value="พล.ต.อ.">พลตำรวจเอก</option>
                <option value="พล.ต.อ. หญิง">พลตำรวจเอก หญิง</option>
                <option value="พล.ต.ท">พลตำรวจโท</option>
                <option value="พล.ต.ท หญิง">พลตำรวจโท หญิง</option>
                <option value="พล.ต.ต">พลตำรวจตรี</option>
                <option value="พล.ต.ต หญิง">พลตำรวจตรี หญิง</option>
                <option value="พ.ต.อ.">พันตำรวจเอก</option>
                <option value="พ.ต.อ. หญิง">พันตำรวจเอก หญิง</option>
                <option value="พ.ต.อ.(พิเศษ)">พันตำรวจเอกพิเศษ</option>
                <option value="พ.ต.อ.(พิเศษ) หญิง">
                  พันตำรวจเอกพิเศษ หญิง
                </option>
                <option value="พ.ต.ท.">พันตำรวจโท</option>
                <option value="พ.ต.ท. หญิง">พันตำรวจโท หญิง</option>
                <option value="พ.ต.ต.">พันตำรวจตรี</option>
                <option value="พ.ต.ต. หญิง">พันตำรวจตรี หญิง</option>
                <option value="ร.ต.อ.">ร้อยตำรวจเอก</option>
                <option value="ร.ต.อ. หญิง">ร้อยตำรวจเอก หญิง</option>
                <option value="ร.ต.ท.">ร้อยตำรวจโท</option>
                <option value="ร.ต.ท. หญิง">ร้อยตำรวจโท หญิง</option>
                <option value="ร.ต.ต.">ร้อยตำรวจตรี</option>
                <option value="ร.ต.ต. หญิง">ร้อยตำรวจตรี หญิง</option>
                <option value="ด.ต.">นายดาบตำรวจ</option>
                <option value="ด.ต. หญิง">ดาบตำรวจหญิง</option>
                <option value="ส.ต.อ.">สิบตำรวจเอก</option>
                <option value="ส.ต.อ. หญิง">สิบตำรวจเอก หญิง</option>
                <option value="ส.ต.ท.">สิบตำรวจโท</option>
                <option value="ส.ต.ท. หญิง">สิบตำรวจโท หญิง</option>
                <option value="ส.ต.ต.">สิบตำรวจตรี</option>
                <option value="ส.ต.ต. หญิง">สิบตำรวจตรี หญิง</option>
                <option value="จ.ส.ต.">จ่าสิบตำรวจ</option>
                <option value="จ.ส.ต. หญิง">จ่าสิบตำรวจ หญิง</option>
                <option value="พลฯ">พลตำรวจ</option>
                <option value="พลฯ หญิง">พลตำรวจ หญิง</option>
                <option value="พล.อ.">พลเอก</option>
                <option value="พล.อ. หญิง">พลเอก หญิง</option>
                <option value="พล.ท.">พลโท</option>
                <option value="พล.ท. หญิง">พลโท หญิง</option>
                <option value="พล.ต.">พลตรี</option>
                <option value="พล.ต.หญิง">พลตรี หญิง</option>
                <option value="พ.อ.">พันเอก</option>
                <option value="พ.อ.หญิง">พันเอก หญิง</option>
                <option value="พ.อ.(พิเศษ)">พันเอกพิเศษ</option>
                <option value="พ.อ.(พิเศษ) หญิง">พันเอกพิเศษ หญิง</option>
                <option value="พ.ท.">พันโท</option>
                <option value="พ.ท.หญิง">พันโท หญิง</option>
                <option value="พ.ต.">พันตรี</option>
                <option value="พ.ต.หญิง">พันตรี หญิง</option>
                <option value="ร.อ.">ร้อยเอก</option>
                <option value="ร.อ.หญิง">ร้อยเอก หญิง</option>
                <option value="ร.ท.">ร้อยโท</option>
                <option value="ร.ท.หญิง">ร้อยโท หญิง</option>
                <option value="ร.ต.">ร้อยตรี</option>
                <option value="ร.ต.หญิง">ร้อยตรี หญิง</option>
                <option value="ส.อ.">สิบเอก</option>
                <option value="ส.อ.หญิง">สิบเอก หญิง</option>
                <option value="ส.ท.">สิบโท</option>
                <option value="ส.ท.หญิง">สิบโท หญิง</option>
                <option value="ส.ต.">สิบตรี</option>
                <option value="ส.ต.หญิง">สิบตรี หญิง</option>
                <option value="จ.ส.อ.">จ่าสิบเอก</option>
                <option value="จ.ส.อ.หญิง">จ่าสิบเอก หญิง</option>
                <option value="จ.ส.ท.">จ่าสิบโท</option>
                <option value="จ.ส.ท.หญิง">จ่าสิบโท หญิง</option>
                <option value="จ.ส.ต.">จ่าสิบตรี</option>
                <option value="จ.ส.ต.หญิง">จ่าสิบตรี หญิง</option>
                <option value="พลฯ">พลทหารบก</option>
                <option value="ว่าที่ พ.ต.">ว่าที่ พ.ต.</option>
                <option value="ว่าที่ พ.ต. หญิง">ว่าที่ พ.ต. หญิง</option>
                <option value="ว่าที่ ร.อ.">ว่าที่ ร.อ.</option>
                <option value="ว่าที่ ร.อ. หญิง">ว่าที่ ร.อ. หญิง</option>
                <option value="ว่าที่ ร.ท.">ว่าที่ ร.ท.</option>
                <option value="ว่าที่ ร.ท. หญิง">ว่าที่ ร.ท. หญิง</option>
                <option value="ว่าที่ ร.ต.">ว่าที่ ร.ต.</option>
                <option value="ว่าที่ ร.ต. หญิง">ว่าที่ ร.ต. หญิง</option>
                <option value="พล.ร.อ.">พลเรือเอก</option>
                <option value="พล.ร.อ.หญิง">พลเรือเอก หญิง</option>
                <option value="พล.ร.ท.">พลเรือโท</option>
                <option value="พล.ร.ท.หญิง">พลเรือโท หญิง</option>
                <option value="พล.ร.ต.">พลเรือตรี</option>
                <option value="พล.ร.ต.หญิง">พลเรือตรี หญิง</option>
                <option value="น.อ.">นาวาเอก</option>
                <option value="น.อ.หญิง">นาวาเอก หญิง</option>
                <option value="น.อ.(พิเศษ)">นาวาเอกพิเศษ</option>
                <option value="น.อ.(พิเศษ) หญิง">นาวาเอกพิเศษ หญิง</option>
                <option value="น.ท.">นาวาโท</option>
                <option value="น.ท.หญิง">นาวาโท หญิง</option>
                <option value="น.ต.">นาวาตรี</option>
                <option value="น.ต.หญิง">นาวาตรี หญิง</option>
                <option value="ร.อ.">เรือเอก</option>
                <option value="ร.อ.หญิง">เรือเอก หญิง</option>
                <option value="ร.ท.">เรือโท</option>
                <option value="ร.ท.หญิง">เรือโท หญิง</option>
                <option value="ร.ต.">เรือตรี</option>
                <option value="ร.ต.หญิง">เรือตรี หญิง</option>
                <option value="พ.จ.อ.">พันจ่าเอก</option>
                <option value="พ.จ.อ.หญิง">พันจ่าเอก หญิง</option>
                <option value="พ.จ.ท.">พันจ่าโท</option>
                <option value="พ.จ.ท.หญิง">พันจ่าโท หญิง</option>
                <option value="พ.จ.ต.">พันจ่าตรี</option>
                <option value="พ.จ.ต.หญิง">พันจ่าตรี หญิง</option>
                <option value="จ.อ.">จ่าเอก</option>
                <option value="จ.อ.หญิง">จ่าเอก หญิง</option>
                <option value="จ.ท.">จ่าโท</option>
                <option value="จ.ท.หญิง">จ่าโท หญิง</option>
                <option value="จ.ต.">จ่าตรี</option>
                <option value="จ.ต.หญิง">จ่าตรี หญิง</option>
                <option value="พลฯ">พลทหารเรือ</option>
                <option value="พล.อ.อ.">พลอากาศเอก</option>
                <option value="พล.อ.อ.หญิง">พลอากาศเอก หญิง</option>
                <option value="พล.อ.ท.">พลอากาศโท</option>
                <option value="พล.อ.ท.หญิง">พลอากาศโท หญิง</option>
                <option value="พล.อ.ต.">พลอากาศตรี</option>
                <option value="พล.อ.ต.หญิง">พลอากาศตรี หญิง</option>
                <option value="น.อ.">นาวาอากาศเอก</option>
                <option value="น.อ.หญิง">นาวาอากาศเอก หญิง</option>
                <option value="น.อ.(พิเศษ)">นาวาอากาศเอกพิเศษ</option>
                <option value="น.อ.(พิเศษ) หญิง">นาวาอากาศเอกพิเศษ หญิง</option>
                <option value="น.ท.">นาวาอากาศโท</option>
                <option value="น.ท.หญิง">นาวาอากาศโท หญิง</option>
                <option value="น.ต.">นาวาอากาศตรี</option>
                <option value="น.ต.หญิง">นาวาอากาศตรี หญิง</option>
                <option value="ร.อ.">เรืออากาศเอก</option>
                <option value="ร.อ.หญิง">เรืออากาศเอก หญิง</option>
                <option value="ร.ท.">เรืออากาศโท</option>
                <option value="ร.ท.หญิง">เรืออากาศโท หญิง</option>
                <option value="ร.ต.">เรืออากาศตรี</option>
                <option value="ร.ต.หญิง">เรืออากาศตรี หญิง</option>
                <option value="พ.อ.อ.">พันจ่าอากาศเอก</option>
                <option value="พ.อ.อ.หญิง">พันจ่าอากาศเอก หญิง</option>
                <option value="พ.อ.ท.">พันจ่าอากาศโท</option>
                <option value="พ.อ.ท.หญิง">พันจ่าอากาศโท หญิง</option>
                <option value="พ.อ.ต.">พันจ่าอากาศตรี</option>
                <option value="พ.อ.ต.หญิง">พันจ่าอากาศตรี หญิง</option>
                <option value="จ.อ.">จ่าอากาศเอก</option>
                <option value="จ.อ.หญิง">จ่าอากาศเอก หญิง</option>
                <option value="จ.ท.">จ่าอากาศโท</option>
                <option value="จ.ท.หญิง">จ่าอากาศโท หญิง</option>
                <option value="จ.ต.">จ่าอากาศตรี</option>
                <option value="จ.ต.หญิง">จ่าอากาศตรี หญิง</option>
                <option value="พลฯ">พลทหารอากาศ</option>
                <option value="หม่อม">หม่อม</option>
                <option value="ม.จ.">หม่อมเจ้า</option>
                <option value="ม.ร.ว.">หม่อมราชวงศ์</option>
                <option value="ม.ล.">หม่อมหลวง</option>
                <option value="ดร.">ดร.</option>
                <option value="ศ.ดร.">ศ.ดร.</option>
                <option value="ศ.">ศ.</option>
                <option value="ผศ.ดร.">ผศ.ดร.</option>
                <option value="ผศ.">ผศ.</option>
                <option value="รศ.ดร.">รศ.ดร.</option>
                <option value="รศ.">รศ.</option>
                <option value="นพ.">นพ.</option>
                <option value="พญ.">แพทย์หญิง</option>
                <option value="นสพ.">สัตวแพทย์</option>
                <option value="สพญ.">สพญ.</option>
                <option value="ทพ.">ทพ.</option>
                <option value="ทพญ.">ทพญ.</option>
                <option value="ภก.">เภสัชกร</option>
                <option value="ภกญ.">ภกญ.</option>
              </Input>
            </div>
            <div className="col-md-6">
              <Label for="exampleEmail">ชื่อ</Label>
              <Input
                type="text"
                name="surnameThai"
                value={formData.surnameThai}
                onChange={handleChange}
                //onChange={(e) => setsurnameThai(e.target.value)}
                required
              />
            </div>
            <div className="col-md-6">
              <Label for="exampleEmail">นามสกุล</Label>
              <Input
                type="text"
                name="lastNameThai"
                value={formData.lastNameThai}
                onChange={handleChange}
                //onChange={(e) => setlastNameThai(e.target.value)}
                required
              />
            </div>
          </FormGroup>
          <FormGroup>
            <div className="col-md-3">
              <Label for="exampleSelect">NameTitle</Label>
              <Input
                id="exampleSelect"
                name="nameTitleEng"
                type="select"
                value={formData.nameTitleEng}
                onChange={handleChange}
                //onChange={(e) => setnameTitleEng(e.target.value)}
                required
              >
                <option value="">Choose Select</option>
                <option value="Mr.">MR</option>
                <option value="Mrs. ">MRS</option>
                <option value="Ms. ">MS</option>
                <option value="Miss">MISS</option>
                <option value="Dr.">Dr.</option>
              </Input>
            </div>
            <div className="col-md-6">
              <Label for="exampleEmail">Name</Label>
              <Input
                type="text"
                name="surnameEng"
                value={formData.surnameEng}
                onChange={handleChange}
                //onChange={(e) => setsurnameEng(e.target.value)}
                required
              />
            </div>
            <div className="col-md-6">
              <Label for="exampleEmail">LastName</Label>
              <Input
                type="text"
                name="lastNameEng"
                value={formData.lastNameEng}
                onChange={handleChange}
                //onChange={(e) => setlastNameEng(e.target.value)}
                required
              />
            </div>
          </FormGroup>
          <FormGroup>
            <div className="col-md-6">
              <Label>วันเดือนปีเกิด</Label>
              <Input
                type="date"
                name="birthDate"
                value={formData.birthDate}
                onChange={handleChange}
                //onChange={(e) => setbirthDate(e.target.value)}
              />
            </div>
          </FormGroup>
          <FormGroup>
            <div className="col-md-6">
              <Label>อีเมล์</Label>
              <Input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                //onChange={(e) => setemail(e.target.value)}
              />
            </div>
          </FormGroup>
          <FormGroup>
            <div className="col-md-6">
              <Label>เลขบัตรประจำตัวประชาชน</Label>
              <Input
                type="text"
                name="idCardNumber"
                maxLength={13}
                pattern="^[0-9]*"
                value={formData.idCardNumber}
                onChange={handleChange}
                //onChange={(e) => setidCardNumber(e.target.value)}
              />
            </div>
          </FormGroup>
          <FormGroup>
            <div className="col-md-6">
              <Label>รูปถ่ายหน้าตรง</Label>
              <Input
                type="file"
                name="image"
                //value={formData.image}
                accept='.png, .jpg, .jpeg'
                multiple
                onChange={handleFileChange}
                //onChange={(e) => setimage(e.target.value)}
              />
            </div>
          </FormGroup>
          <FormGroup>
            <div className="col-md-6">
              <Label>ชื่อบนเบอร์วิ่ง</Label>
              <Input
                type="text"
                name="nameBanner"
                maxLength={10}
                pattern="^[0-9\A-Z]+$"
                value={formData.nameBanner}
                onChange={handleChange}
                //onChange={(e) => setnameBanner(e.target.value)}
              />
            </div>
          </FormGroup>
          <Button variant="primary" onClick={handleNext}>
            ต่อไป
          </Button>
        </Form>
      </Container>
    </div>
  );
};

export default Step1;
