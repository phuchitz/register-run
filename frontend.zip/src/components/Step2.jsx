import React, { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import {
  Form,
  Button,
  Label,
  FormGroup,
  Input,
  Container,
  Row,
  Col,
} from "reactstrap";

const Step2 = ({ formData, setFormData, nextStep, prevStep }) => {

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleNext = () => {
    nextStep();
  };

  const handlePrevious = () => {
    prevStep();
  };

  return (
    <div>
      <Container>
        <h1>2 ข้อมูลเกี่ยวกับการวิ่ง</h1>
        <hr />
        <Form>
          <Row className="row-cols-lg-auto g-3 align-items-center">
            <legend>
              เคยลงงานแข่ง Mini Marathon / Half Marathon / Full Marathon
              มาก่อนหรือไม่
            </legend>
            <Col sm={10}>
              <FormGroup check>
                <Input
                  name="everCompleted"
                  type="radio"
                  value="Yes"
                  checked={formData.everCompleted === "Yes"}
                  onChange={handleChange}
                />
                {' '}
                <Label check>เคย</Label>
              </FormGroup>
            </Col>
            <Col sm={10}>
              <FormGroup check>
                <Input
                  name="everCompleted"
                  type="radio"
                  value="No"
                  checked={formData.everCompleted === "No"}
                  onChange={handleChange}
                />
                {' '}
                <Label check>ไม่เคย</Label>
              </FormGroup>
            </Col>
          </Row>
          <Row className="row-cols-lg-auto g-3 align-items-center">
            <legend>เวลาที่คาดว่าจะจบในการวิ่งครั้งนี้</legend>
            <Col>
              <Label>ชั่วโมง</Label>
              <Input
                id="email"
                name="expectedTimeH"
                type="number"
                min={0}
                value={formData.expectedTimeH}
                onChange={handleChange}
              />
            </Col>
            <Col>
              <Label>นาที</Label>
              <Input
                id="email"
                name="expectedTimeM"
                type="number"
                min={0}
                value={formData.expectedTimeM}
                onChange={handleChange}
              />
            </Col>
          </Row>
          <FormGroup>
            <Button variant="primary" onClick={handlePrevious}>
              ก่อนหน้า
            </Button>
            <Button variant="primary" onClick={handleNext}>
              ต่อไป
            </Button>
          </FormGroup>
        </Form>
        {/* <Form className="input-form">
          <FormGroup tag="fieldset">
            <legend>เคยลงงานแข่ง Mini Marathon / Half Marathon / Full Marathon มาก่อนหรือไม่</legend>
            <FormGroup >
              <Input
                name="everCompleted"
                type="radio"
                value="Yes"
                checked={formData.everCompleted === "Yes"}
                onChange={handleChange}
              />
              <Label >เคย</Label>
            </FormGroup>
            <FormGroup>
              <Input
                name="everCompleted"
                type="radio"
                value="No"
                checked={formData.everCompleted === "No"}
                onChange={handleChange}
              />
              <Label>ไม่เคย</Label>
            </FormGroup>
          </FormGroup>
          <FormGroup>
            <legend>เวลาที่คาดว่าจะจบในการวิ่งครั้งนี้</legend>
            <FormGroup>
            <Label>ชั่วโมง</Label>
            <Input 
              name="expectedTimeH"
              type="number"
              // value={formData.expectedTimeH}
              // onChange={handleChange}
            />
            </FormGroup>
            <FormGroup>
            <Label>นาที</Label>
            <Input 
              name="expectedTimeM"
              type="number"
              value={formData.expectedTimeM}
              onChange={handleChange}
            />
            </FormGroup>
          </FormGroup>
          <Button variant="primary" onClick={handlePrevious}>
            ก่อนหน้า
          </Button>
          <Button variant="primary" onClick={handleNext}>
            ต่อไป
          </Button>
        </Form> */}
      </Container>
    </div>
  );
};

export default Step2;
