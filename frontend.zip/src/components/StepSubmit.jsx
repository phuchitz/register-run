import React, { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import {
  Form,
  Button,
  Label,
  FormGroup,
  Input,
  Container,
  Row,
  Col,
  Card,
  CardBody,
  CardTitle,
} from "reactstrap";
import axios from "axios";

const StepSubmit = ({ formData, setFormData, handleSubmit, prevStep }) => {
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmitClick = (e) => {
    // handleSubmit();
    e.preventDefault();

    // Send data to the backend using Axios
    axios
      .post("http://localhost:8800/api/auth/register", formData)
      .then((response) => {
        console.log(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  const handlePrevious = () => {
    prevStep();
  };

  const renderPreviewImage = () => {
    if (formData.image) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imagePreviewUrl = reader.result;
        return (
          <div>
            <h3>Preview Image:</h3>
            <img
              src={imagePreviewUrl}
              alt="Preview"
              style={{ width: "200px", height: "auto" }}
            />
          </div>
        );
      };
      reader.readAsDataURL(formData.image); // Pass the Blob object to readAsDataURL
    }
    return null; // Return null if there is no image to preview
  };

  return (
    <>
      <h3>แสดงข้อมูลทั้งหมด</h3>
      <Card>
        <CardBody>
          <CardTitle tag="h5">ข้อมูลส่วนตัว</CardTitle>
          <p>
            ชื่อ-นามสกุล : {formData.nameTitleThai} {formData.surnameThai}{" "}
            {formData.lastNameThai}
          </p>
          <p>
            Full-name : {formData.nameTitleEng} {formData.surnameEng}{" "}
            {formData.lastNameEng}
          </p>
          <p>วันเดือนปีเกิด : {formData.birthDate}</p>
          <p>อีเมล : {formData.email}</p>
          <p>เลขบัตรประจำตัวประชาชน : {formData.idCardNumber}</p>
          <p>
            <img src={formData.image} alt="" />
          </p>
          {/* {formData.image && (
            <>
            <h5>รูปถ่ายหน้าตรง :</h5>
            <img
            src={URL.createObjectURL(formData.image)}
            alt="Preview"
            style={{ width: '200px', height: 'auto' }}
          />
            </>
          )} */}
          <p>ชื่อบนเบอร์วิ่ง : {formData.nameBanner}</p>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <CardTitle tag="h5">ข้อมูลเกี่ยวกับการวิ่ง</CardTitle>
          <p>
            เคยลงงานแข่ง Mini Marathon / Half Marathon / Full Marathon
            มาก่อนหรือไม่ : {formData.everCompleted}
          </p>
          <p>
            เวลาที่คาดว่าจะจบในการวิ่งครั้งนี้ (ชั่วโมงและนาที) :{" "}
            {formData.expectedTimeH} ชั่วโมง {formData.expectedTimeM} นาที
          </p>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <CardTitle tag="h5">ผู้ติดต่อฉุกเฉินคนที่ 1 </CardTitle>
          <p>ชื่อ-นามสกุล : {formData.emfullName1}</p>
          <p>ความสัมพันธ์ : {formData.emRelationship1}</p>
          <p>เบอร์โทรศัพท์ : {formData.emTel1}</p>

          <CardTitle tag="h5">ผู้ติดต่อฉุกเฉินคนที่ 2 </CardTitle>
          <p>ชื่อ-นามสกุล : {formData.emfullName2 || "-"}</p>
          <p>ความสัมพันธ์ : {formData.emRelationship2 || "-"}</p>
          <p>เบอร์โทรศัพท์ : {formData.emTel2 || "-"}</p>
        </CardBody>
      </Card>

      <Card>
        <CardBody>
          <CardTitle tag="h5">ข้อมูลทางการแพทย์ </CardTitle>
          <p>หมู่เลือด : {formData.medBloodType}</p>
          <p>ท่านมีอาการแพ้ยาหรือสารต่างๆ หรือไม่ : {formData.medDrugAllery}</p>
          <p>ท่านมีโรคประจำตัว หรือไม่ : {formData.medCongenitalDisease}</p>
          <p>
            ท่านมีประวัติการผ่าตัด มาก่อนหรือไม่ : {formData.medPlanChildren}
          </p>
          <p>
            ท่านมีแพลนที่จะมีบุตร หรือ
            กำลังตั้งครรภ์ก่อนถึงช่วงการแข่งขันหรือไม่ :{" "}
            {formData.medRegularBasis}
          </p>
          <p>
            ท่านมียาที่ต้องทานเป็นประจำหรือไม่ : {formData.medInjuryIllness}
          </p>
          <p>
            ท่านเคยบาดเจ็บ/ เจ็บป่วย จากการเข้าร่วมงานวิ่ง
            ที่ต้องไปรักษาต่อที่โรงพยาบาลหรือไม่ : {formData.medInjuryIllness}
          </p>
          <p>
            ท่านออกกำลังกายสม่ำเสมอหรือไม่ (อย่างน้อย 1-2 ครั้ง ต่อสัปดาห์) :{" "}
            {formData.medRegularBasis}
          </p>
          <p>
            ท่านเคยมีอาการเจ็บแน่นหน้าอก ใจสั่น เหนื่อยง่ายผิดปกติ หน้ามืด
            ขณะออกกำลังกายหรือไม่? : {formData.medChest}
          </p>
        </CardBody>
      </Card>

      <FormGroup>
        <Button className="btn btn-success" onClick={handleSubmitClick}>
          ลงทะเบียน
        </Button>
      </FormGroup>
    </>
  );
};

export default StepSubmit;
