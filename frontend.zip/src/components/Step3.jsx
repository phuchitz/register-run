import React, { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import {
  Form,
  Button,
  Label,
  FormGroup,
  Input,
  Container,
  FormFeedback,
  FormText,
} from "reactstrap";

const Step3 = ({ formData, setFormData, nextStep, prevStep }) => {
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleNext = () => {
    nextStep();
  };

  const handlePrevious = () => {
    prevStep();
  };

  return (
    <Container>
      <h1>3 ผู้ติดต่อฉุกเฉิน</h1>
      <hr />
      <Form className="input-form">
        <FormGroup>
          <legend>ผู้ติดต่อฉุกเฉินคนที่ 1 (บังคับกรอก)</legend>
          <FormGroup>
            <label htmlFor="">ชื่อ-นามสกุล</label>
            <Input
              type="text"
              name="emfullName1"
              value={formData.emfullName1}
              onChange={handleChange}
              required
            />
          </FormGroup>
          <FormGroup>
            <label htmlFor="">ความสัมพันธ์</label>
            <Input
              type="text"
              name="emRelationship1"
              value={formData.emRelationship1}
              onChange={handleChange}
              required
            />
          </FormGroup>
          <FormGroup>
            <label htmlFor="">เบอร์โทรศัพท์</label>
            <Input
              type="text"
              name="emTel1"
              maxLength={10}
              pattern="/^[0-9]/"
              value={formData.emTel1}
              onChange={handleChange}
            />
          </FormGroup>
        </FormGroup>
        <FormGroup>
          <legend>ผู้ติดต่อฉุกเฉินคนที่ 2 (ไม่บังคับกรอก)</legend>
          <FormGroup>
            <label htmlFor="">ชื่อ-นามสกุล</label>
            <Input
              type="text"
              name="emfullName2"
              value={formData.emfullName2}
              onChange={handleChange}
              required
            />
          </FormGroup>
          <FormGroup>
            <label htmlFor="">ความสัมพันธ์</label>
            <Input
              type="text"
              name="emRelationship2"
              value={formData.emRelationship2}
              onChange={handleChange}
              required
            />
          </FormGroup>
          <FormGroup>
            <label htmlFor="">เบอร์โทรศัพท์</label>
            <Input
              type="text"
              name="emTel2"
              maxLength={10}
              pattern="/^[0-9]/"
              value={formData.emTel2}
              onChange={handleChange}
            />
          </FormGroup>
        </FormGroup>
        <FormGroup>
          <Button variant="primary" onClick={handlePrevious}>
            ก่อนหน้า
          </Button>
          <Button variant="primary" onClick={handleNext}>
            ต่อไป
          </Button>
        </FormGroup>
      </Form>
    </Container>
  );
};

export default Step3;
