/* eslint-disable no-undef */
import React, { useRef, useState } from "react";
import { useForm } from "react-hook-form";
import {
  Form,
  Button,
  Label,
  FormGroup,
  Input,
  Container,
  Col,
  Row,
} from "reactstrap";

const Step4 = ({ formData, setFormData, nextStep, prevStep }) => {
  const [chkMedDrugAllery, setchkMedDrugAllery] = useState();
  const handleChange = (e) => {
    setchkMedDrugAllery(e.target.value);
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleNext = () => {
    nextStep();
  };

  const handlePrevious = () => {
    prevStep();
  };

  return (
    <>
      <Container>
        <h1>4 ข้อมูลทางการแพทย์</h1>
        <hr />
        <Form className="input-form">
          <FormGroup>
            <label htmlFor="">หมู่เลือด (ไม่บังคับกรอก)</label>
            <Row className="row-cols-lg-auto g-3 align-items-center">
              <Col sm={5}>
                <Input
                  name="medBloodType"
                  type="select"
                  id="medBloodType"
                  value={formData.medBloodType || ""}
                  onChange={handleChange}
                >
                  <option value="-" checked>
                    ไม่ระบุหรือเลือก
                  </option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="O">O</option>
                  <option value="AB">AB</option>
                </Input>
              </Col>
            </Row>
          </FormGroup>
          <FormGroup tag="fieldset">
            <label htmlFor="">
              ท่านมีอาการแพ้ยาหรือสารต่างๆ หรือไม่ (บังคับกรอก)
            </label>
            <FormGroup check>
              <Input
                name="medDrugAllery"
                type="radio"
                value="No"
                checked={formData.medDrugAllery === "No"}
                onChange={handleChange}
              />
              <Label>ไม่มี</Label>
            </FormGroup>
            <FormGroup check>
              <Input
                name="medDrugAllery"
                type="radio"
                value="Yes"
                checked={chkMedDrugAllery === "Yes"}
                onChange={handleChange}
              />
              <Label check>มี</Label>
              {chkMedDrugAllery === "Yes" && (
                <FormGroup>
                  <label htmlFor="">ระบุ</label>
                  <Input
                    type="text"
                    name="medDrugAllery"
                    value={formData.medDrugAllery}
                    onChange={handleChange}
                  />
                </FormGroup>
              )}
            </FormGroup>

            <FormGroup tag="fieldset">
              <label htmlFor="">ท่านมีโรคประจำตัว หรือไม่ (บังคับกรอก)</label>
              <FormGroup check>
                <Input
                  name="medCongenitalDisease"
                  type="radio"
                  value="No"
                  checked={formData.medCongenitalDisease === "No"}
                  onChange={handleChange}
                />
                <Label check>ไม่มี</Label>
              </FormGroup>
              <FormGroup check>
                <Input
                  name="medCongenitalDisease"
                  type="radio"
                  value="Yes"
                  checked={formData.medCongenitalDisease === "Yes"}
                  onChange={handleChange}
                />
                <Label check>มี</Label>
                {formData.medCongenitalDisease === "Yes" && (
                  <FormGroup>
                    <label htmlFor="">ระบุ</label>
                    <Input
                      type="text"
                      name="medCongenitalDisease"
                      value={formData.medCongenitalDisease}
                      onChange={handleChange}
                    />
                  </FormGroup>
                )}
              </FormGroup>
            </FormGroup>

            <FormGroup tag="fieldset">
              <label htmlFor="">
                ท่านมีประวัติการผ่าตัด มาก่อนหรือไม่ (บังคับกรอก)
              </label>
              <FormGroup check>
                <Input
                  name="medHistorySurgeryPosition"
                  type="radio"
                  value="No"
                  checked={formData.medHistorySurgeryPosition === "No"}
                  onChange={handleChange}
                />
                <Label check>ไม่มี</Label>
              </FormGroup>
              <FormGroup check>
                <Input
                  name="medHistorySurgeryPosition"
                  type="radio"
                  value="Yes"
                  checked={formData.medHistorySurgeryPosition === "Yes"}
                  onChange={handleChange}
                />
                <Label check>มี</Label>
                {formData.medHistorySurgeryPosition === "Yes" && (
                  <>
                    <FormGroup>
                      <label htmlFor="">ระบุตำแหน่ง</label>
                      <Input
                        type="text"
                        name="medHistorySurgeryPosition"
                        value={formData.medHistorySurgeryPosition}
                        onChange={handleChange}
                      />
                    </FormGroup>
                    <FormGroup>
                      <label htmlFor="">ระบุปี</label>
                      <Input
                        type="text"
                        name="medHistorySurgeryYear"
                        value={formData.medHistorySurgeryYear}
                        onChange={handleChange}
                      />
                    </FormGroup>
                  </>
                )}
              </FormGroup>
            </FormGroup>

            <FormGroup tag="fieldset">
              <label htmlFor="">
                ท่านมีแพลนที่จะมีบุตร หรือ
                กำลังตั้งครรภ์ก่อนถึงช่วงการแข่งขันหรือไม่ (บังคับกรอก)
              </label>
              <FormGroup check>
                <Input
                  name="medPlanChildren"
                  type="radio"
                  value="Yes"
                  checked={formData.medPlanChildren === "Yes"}
                  onChange={handleChange}
                />
                <Label check>ใช่</Label>
              </FormGroup>
              <FormGroup check>
                <Input
                  name="medPlanChildren"
                  type="radio"
                  value="No"
                  checked={formData.medPlanChildren === "No"}
                  onChange={handleChange}
                />
                <Label check>ไม่</Label>
              </FormGroup>
            </FormGroup>

            <FormGroup tag="fieldset">
              <label htmlFor="">
              ท่านมียาที่ต้องทานเป็นประจำหรือไม่ (บังคับกรอก)
              </label>
              <FormGroup check>
                <Input
                  name="medPlanChildren"
                  type="radio"
                  value="Yes"
                  checked={formData.medPlanChildren === "Yes"}
                  onChange={handleChange}
                />
                <Label check>ไม่</Label>
              </FormGroup>
              <FormGroup check>
                <Input
                  name="medPlanChildren"
                  type="radio"
                  value="No"
                  checked={formData.medPlanChildren === "No"}
                  onChange={handleChange}
                />
                <Label check>มี</Label>
              </FormGroup>
            </FormGroup>

            <FormGroup tag="fieldset">
              <label htmlFor="">
                ท่านออกกำลังกายสม่ำเสมอหรือไม่ (อย่างน้อย 1-2 ครั้ง ต่อสัปดาห์)
                (บังคับกรอก)
              </label>
              <FormGroup check>
                <Input
                  name="medRegularBasis"
                  type="radio"
                  value="Yes"
                  checked={formData.medRegularBasis === "Yes"}
                  onChange={handleChange}
                />
                <Label check>ใช่</Label>
              </FormGroup>
              <FormGroup check>
                <Input
                  name="medRegularBasis"
                  type="radio"
                  value="No"
                  checked={formData.medRegularBasis === "No"}
                  onChange={handleChange}
                />
                <Label check>ไม่</Label>
              </FormGroup>
            </FormGroup>
            <FormGroup tag="fieldset">
              <label htmlFor="">
                ท่านเคยมีอาการเจ็บแน่นหน้าอก ใจสั่น เหนื่อยง่ายผิดปกติ หน้ามืด
                ขณะออกกำลังกายหรือไม่? (บังคับกรอก)
              </label>
              <FormGroup check>
                <FormGroup check>
                  <Input
                    name="medChest"
                    type="radio"
                    value="Yes"
                    checked={formData.medChest === "Yes"}
                    onChange={handleChange}
                  />
                  <Label check>ใช่</Label>
                </FormGroup>
                <FormGroup check>
                  <Input
                    name="medChest"
                    type="radio"
                    value="No"
                    checked={formData.medChest === "No"}
                    onChange={handleChange}
                  />
                  <Label check>ไม่</Label>
                </FormGroup>
              </FormGroup>
            </FormGroup>
          </FormGroup>
          <FormGroup>
            <Button variant="primary" onClick={handlePrevious}>
              ก่อนหน้า
            </Button>
            <Button variant="primary" onClick={handleNext}>
              ต่อไป
            </Button>
          </FormGroup>
        </Form>
      </Container>
    </>
  );
};

export default Step4;
