import logo from './logo.svg';
import './App.css';
import Process from './components/Process';
import Header from './components/Header';

function App() {
  return (
    <div className="App">
      <Header/>
      <Process/>
    </div>
  );
}

export default App;
